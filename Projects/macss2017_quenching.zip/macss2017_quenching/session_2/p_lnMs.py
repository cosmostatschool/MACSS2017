# 10 May 2017 13:27:48

import matplotlib.pyplot as plt
from prob2d import get_prob2d
import numpy as np


def get_p_lnMs():
    """derive p(lnMs) from p(lnMs, lnMh)"""
    p2d_arr, lnMs_arr, lnMh_arr = get_prob2d(sigma_lnMs=0.49730, hmfdata="../data/hmf.dat")
    if True:
        # test whether p2d_arr is correctly normalized to unity
        y = np.trapz(p2d_arr, x=lnMs_arr, axis=0)
        _norm = np.trapz(y, x=lnMh_arr)
        if np.abs(_norm - 1.0) > 1e-5:
            raise RuntimeError('Error in normalizing p2d  %10.4f' % _norm)
    # p2d_arr has shape (ns, mh)
    p_lnMs_arr = np.trapz(p2d_arr, x=lnMh_arr, axis=-1)
    return(p_lnMs_arr, lnMs_arr)

if __name__ == "__main__":
    p_lnMs_arr, lnMs_arr = get_p_lnMs()
    # test whether p_lnMs_arr is correctly normalized to unity
    print np.trapz(p_lnMs_arr, x=lnMs_arr)
    plt.plot(lnMs_arr/np.log(10.0), p_lnMs_arr)
    plt.ylabel(r"$p(\ln\,M_*)$")
    plt.xlabel(r"$\lg\,M_*$")
    plt.yscale('log')
    plt.show()
