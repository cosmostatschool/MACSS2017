# 10 May 2017 13:27:48

import matplotlib.pyplot as plt
from prob2d import get_prob2d
from read_mock import read_mock
import numpy as np


def show_halomass_distribution():
    p2d_arr, lnMs_arr, lnMh_arr = get_prob2d(sigma_lnMs=0.49730, hmfdata="../data/hmf.dat")
    # Integrate over p(lnMs, lnMh) to get p(lnMs)
    p_lnMs_arr = np.trapz(p2d_arr, x=lnMh_arr, axis=-1)
    # Derive p(lnMh|lnMs) = p(lnMh,lnMs) / p(lnMs)
    p_lnMh_at_lnMs = np.zeros(p2d_arr.shape)
    # Divide p2d_arr by p_lnMs_arr at fixed Ms
    for i in xrange(lnMs_arr.size):
        lgMs = lnMs_arr[i] / np.log(10.0)
        p_lnMh_at_lnMs[i, :] = p2d_arr[i, :] / p_lnMs_arr[i]
        # check normalization
        # print np.trapz(p_lnMh_at_lnMs[i, :], x=lnMh_arr)
        # Plot the distribution of halo mass at a few fixed stellar masses
        if np.mod(i, 15) == 0 and lgMs < 12 and lgMs > 9.5:
            plt.plot(lnMh_arr / np.log(10.0), p_lnMh_at_lnMs[i, :],
                    label=r"$\lg\;M_*=$" + format(lgMs, '4.2f'))
    plt.legend(loc=1)
    plt.ylim(1e-2, 1e1)
    plt.xlim(11, 16)
    plt.ylabel(r"$p(\ln\,M_h)$")
    plt.xlabel(r"$\lg\,M_h$")
    plt.yscale('log')
    plt.show()


def get_halomass():
    # those are the same as in 'show_halomass_distribution', see comments above
    p2d_arr, lnMs_arr, lnMh_arr = get_prob2d(sigma_lnMs=0.49730, hmfdata="../data/hmf.dat")
    p_lnMs_arr = np.trapz(p2d_arr, x=lnMh_arr, axis=-1)
    # you can use the following loop to get p_lnMh_at_lnMs
    #
    # p_lnMh_at_lnMs = np.zeros(p2d_arr.shape)
    # for i in xrange(lnMs_arr.size):
        # p_lnMh_at_lnMs[i, :] = p2d_arr[i, :] / p_lnMs_arr[i]
    #
    # or try the one-line code below (.T means 'transpose')
    p_lnMh_at_lnMs = (p2d_arr.T / p_lnMs_arr).T
    # now let's get the mean lnMh at fixed Ms
    lnMh_mean_arr = np.zeros(lnMs_arr.size)
    for i in xrange(lnMs_arr.size):
        if True:
            # check the normalization
            _norm = np.trapz(p_lnMh_at_lnMs[i, :], x=lnMh_arr)
            if np.abs(_norm - 1.0) > 1e-5:
                raise RuntimeError('normalization breaks')
        lnMh_mean_arr[i] = np.trapz(p_lnMh_at_lnMs[i, :] * lnMh_arr, x=lnMh_arr)
    # convert results to log-10 base
    lgMs_arr = lnMs_arr / np.log(10.0)
    lgMh_mean_arr = lnMh_mean_arr / np.log(10.0)
    # convert halo mass units from Msun to Msun/h to compare with the values in the mock data
    lgMh_mean_arr = lgMh_mean_arr + np.log10(0.7)
    return(lgMs_arr, lgMh_mean_arr)

def compare_halomass_with_mock(mockfile):
    # show_halomass_distribution()
    lgMs_arr, lgMh_mean_arr = get_halomass()
    plt.plot(lgMs_arr, lgMh_mean_arr, 'r-', label="Prediction")
    #
    galrec = read_mock(mockfile)
    iscen = galrec['lg_halo_mass'] > 1
    lgmh = galrec['lg_halo_mass'][iscen]
    lgms = galrec['lg_stellar_mass'][iscen]
    lgms_bins = np.linspace(10.0, 11.5, 15)
    lgms_cens = (lgms_bins[1:] + lgms_bins[:-1]) * 0.5
    lgmh_cens = np.zeros_like(lgms_cens)
    lgmh_errs = np.zeros_like(lgms_cens)
    for i in xrange(lgms_cens.size):
        sel = (lgms >= lgms_bins[i]) & (lgms < lgms_bins[i+1])
        nsel = np.sum(sel)
        if nsel > 5:
            # update lgms_cens
            lgms_cens[i] = np.mean(lgms[sel])
            lgmh_cens[i] = np.mean(lgmh[sel])
            lgmh_errs[i] = np.std(lgmh[sel]) / np.sqrt(float(nsel))
    plt.errorbar(lgms_cens, lgmh_cens, yerr=lgmh_errs, color="k", marker="o", ms=5, label="Mock Data")
    plt.legend(loc=2)
    plt.xlabel(r"$M_*\;[M_\odot/h^2]$")
    plt.ylabel(r"$M_h\;[M_\odot/h]$")
    plt.show()


if __name__ == "__main__":
    mockfile = '/Users/ying/Data/ihodmock/standard/iHODcatalog_bolshoi.h5'
    show_halomass_distribution()
    compare_halomass_with_mock(mockfile)
