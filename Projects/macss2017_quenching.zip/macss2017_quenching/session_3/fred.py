# 11 May 2017 13:27:30
import numpy as np
import matplotlib.pyplot as plt

"""Red/Blue galaxy fraction as a function of halo mass."""


def fblue(lgmh, lgmhqc=12.0, muc=0.30):
    """ Blue galaxy fraction as a function of halo mass.

    This is the Equation 9 in ZM16.

    Powered exponential for halo mass quenching of the central galaxies
    """
    _mh = 10.0**(lgmh - lgmhqc)
    return(np.exp(-_mh**muc))

def fred(lgmh, lgmhqc=12.0, muc=0.3):
    """ Red galaxy fraction as a function of halo mass.

    This is the Equation 9 in ZM16.

    Powered exponential for halo mass quenching of the central galaxies
    """
    return(1.0- fblue(lgmh, lgmhqc, muc))

def fblue_ms(lgms, lgmsqc=10.6, muc=0.66):
    """ Blue galaxy fraction as a function of stellar mass.

    This is the Equation 7 in ZM16.

    Powered exponential for stellar mass quenching of the central galaxies
    """
    _ms = 10.0**(lgms - lgmsqc)
    return(np.exp(-_ms**muc))

def fred_ms(lgms, lgmsqc=10.6, muc=0.66):
    return(1.0- fblue_ms(lgms, lgmsqc, muc))


if __name__ == "__main__":
    if True:
        lgmh_arr = np.linspace(11, 15, 100)
        lgmhqc_arr = np.arange(12, 13, 0.25)
        muc_arr = np.arange(0.2, 0.4, 0.05)
        for lgmhqc in lgmhqc_arr:
            for muc in muc_arr:
                fred_arr = fred(lgmh_arr, lgmhqc, muc)
                plt.plot(lgmh_arr, fred_arr)
        plt.xlabel(r'$\lg\;M_h$')
        plt.ylabel(r'$f_{\mathrm{red}}$')
        plt.show()
