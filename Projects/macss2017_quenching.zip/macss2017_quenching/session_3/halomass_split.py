# 10 May 2017 13:27:48

import matplotlib.pyplot as plt
from prob2d_split import get_prob2d_split, get_prob2d_split_ms
from quenching import is_red
import sys
sys.path.insert(1, '../session_2/')
from read_mock import read_mock
import numpy as np


def show_halomass_distribution_split(p, use_red):
    p2d_arr, lnMs_arr, lnMh_arr = get_prob2d_split(p, use_red)
    # Integrate over p(lnMs, lnMh) to get p(lnMs)
    p_lnMs_arr = np.trapz(p2d_arr, x=lnMh_arr, axis=-1)
    # Derive p(lnMh|lnMs) = p(lnMh,lnMs) / p(lnMs)
    p_lnMh_at_lnMs = np.zeros(p2d_arr.shape)
    # Divide p2d_arr by p_lnMs_arr at fixed Ms
    for i in xrange(lnMs_arr.size):
        lgMs = lnMs_arr[i] / np.log(10.0)
        p_lnMh_at_lnMs[i, :] = p2d_arr[i, :] / p_lnMs_arr[i]
        # check normalization
        # print np.trapz(p_lnMh_at_lnMs[i, :], x=lnMh_arr)
        # Plot the distribution of halo mass at a few fixed stellar masses
        if np.mod(i, 15) == 0 and lgMs < 12 and lgMs > 9.5:
            plt.plot(lnMh_arr / np.log(10.0), p_lnMh_at_lnMs[i, :],
                    label=r"$\lg\;M_*=$" + format(lgMs, '4.2f'))
    plt.legend(loc=1)
    plt.ylim(1e-2, 1e1)
    plt.xlim(11, 16)
    plt.ylabel(r"$p(\ln\,M_h)$")
    plt.xlabel(r"$\lg\,M_h$")
    plt.yscale('log')
    plt.show()

def show_halomass_distribution_split_ms(p, use_red, set_show=True):
    p2d_arr, lnMs_arr, lnMh_arr = get_prob2d_split_ms(p, use_red)
    # Integrate over p(lnMs, lnMh) to get p(lnMs)
    p_lnMs_arr = np.trapz(p2d_arr, x=lnMh_arr, axis=-1)
    # Derive p(lnMh|lnMs) = p(lnMh,lnMs) / p(lnMs)
    p_lnMh_at_lnMs = np.zeros(p2d_arr.shape)
    # Divide p2d_arr by p_lnMs_arr at fixed Ms
    if use_red:
        ls = "-"
        gtype = "red"
    else:
        ls = "--"
        gtype = "blue"
    for i in xrange(lnMs_arr.size):
        lgMs = lnMs_arr[i] / np.log(10.0)
        p_lnMh_at_lnMs[i, :] = p2d_arr[i, :] / p_lnMs_arr[i]
        # check normalization
        # print np.trapz(p_lnMh_at_lnMs[i, :], x=lnMh_arr)
        # Plot the distribution of halo mass at a few fixed stellar masses
        # if np.mod(i, 15) == 0 and lgMs < 12 and lgMs > 9.5:
        if np.mod(i, 25) == 0 and lgMs < 12 and lgMs > 9.5:
            plt.plot(lnMh_arr / np.log(10.0), p_lnMh_at_lnMs[i, :],
                    ls=ls, label=r"$\lg\;M_*=$" + format(lgMs, '4.2f') + " " + gtype)
    if set_show:
        plt.legend(loc=1)
        plt.ylim(1e-2, 1e1)
        plt.xlim(11, 16)
        plt.ylabel(r"$p(\ln\,M_h)$")
        plt.xlabel(r"$\lg\,M_h$")
        plt.yscale('log')
        plt.show()

def show_stellarmass_distribution_split_ms(p, use_red, set_show=True):
    p2d_arr, lnMs_arr, lnMh_arr = get_prob2d_split_ms(p, use_red)
    # Integrate over p(lnMs, lnMh) to get p(lnMh)
    p_lnMh_arr = np.trapz(p2d_arr, x=lnMs_arr, axis=0)
    # Derive p(lnMs|lnMh) = p(lnMh,lnMs) / p(lnMh)
    p_lnMs_at_lnMh = np.zeros(p2d_arr.shape)
    # Divide p2d_arr by p_lnMh_arr at fixed Mh
    if use_red:
        ls = "-"
        gtype = "red"
    else:
        ls = "--"
        gtype = "blue"
    for i in xrange(lnMh_arr.size):
        lgMh = lnMh_arr[i] / np.log(10.0)
        p_lnMs_at_lnMh[:, i] = p2d_arr[:, i] / p_lnMh_arr[i]
        # check normalization
        # print np.trapz(p_lnMs_at_lnMh[:, i], x=lnMs_arr)
        # Plot the distribution of halo mass at a few fixed stellar masses
        # if np.mod(i, 15) == 0 and lgMs < 12 and lgMs > 9.5:
        if np.mod(i, 25) == 0 and lgMh < 15 and lgMh > 13:
            plt.plot(lnMs_arr / np.log(10.0), p_lnMs_at_lnMh[:, i],
                    ls=ls, label=r"$\lg\;M_h=$" + format(lgMh, '4.2f') + " " + gtype)
    if set_show:
        plt.legend(loc=1)
        plt.ylim(1e-2, 1e1)
        plt.xlim(10, 12)
        plt.ylabel(r"$p(\ln\,M_*)$")
        plt.xlabel(r"$\lg\,M_*$")
        plt.yscale('log')
        plt.show()


def get_halomass_split(p, use_red):
    p2d_arr, lnMs_arr, lnMh_arr = get_prob2d_split(p, use_red)
    p_lnMs_arr = np.trapz(p2d_arr, x=lnMh_arr, axis=-1)
    # you can use the following loop to get p_lnMh_at_lnMs
    #
    # p_lnMh_at_lnMs = np.zeros(p2d_arr.shape)
    # for i in xrange(lnMs_arr.size):
        # p_lnMh_at_lnMs[i, :] = p2d_arr[i, :] / p_lnMs_arr[i]
    #
    # or try the one-line code below (.T means 'transpose')
    p_lnMh_at_lnMs = (p2d_arr.T / p_lnMs_arr).T
    # now let's get the mean lnMh at fixed Ms
    lnMh_mean_arr = np.zeros(lnMs_arr.size)
    for i in xrange(lnMs_arr.size):
        if True:
            # check the normalization
            _norm = np.trapz(p_lnMh_at_lnMs[i, :], x=lnMh_arr)
            if np.abs(_norm - 1.0) > 1e-5:
                raise RuntimeError('normalization breaks')
        lnMh_mean_arr[i] = np.trapz(p_lnMh_at_lnMs[i, :] * lnMh_arr, x=lnMh_arr)
    # convert results to log-10 base
    lgMs_arr = lnMs_arr / np.log(10.0)
    lgMh_mean_arr = lnMh_mean_arr / np.log(10.0)
    # convert halo mass units from Msun to Msun/h to compare with the values in the mock data
    lgMh_mean_arr = lgMh_mean_arr + np.log10(0.7)
    return(lgMs_arr, lgMh_mean_arr)

def get_halomass_split_ms(p, use_red):
    p2d_arr, lnMs_arr, lnMh_arr = get_prob2d_split_ms(p, use_red)
    p_lnMs_arr = np.trapz(p2d_arr, x=lnMh_arr, axis=-1)
    # you can use the following loop to get p_lnMh_at_lnMs
    #
    # p_lnMh_at_lnMs = np.zeros(p2d_arr.shape)
    # for i in xrange(lnMs_arr.size):
        # p_lnMh_at_lnMs[i, :] = p2d_arr[i, :] / p_lnMs_arr[i]
    #
    # or try the one-line code below (.T means 'transpose')
    p_lnMh_at_lnMs = (p2d_arr.T / p_lnMs_arr).T
    # now let's get the mean lnMh at fixed Ms
    lnMh_mean_arr = np.zeros(lnMs_arr.size)
    for i in xrange(lnMs_arr.size):
        if True:
            # check the normalization
            _norm = np.trapz(p_lnMh_at_lnMs[i, :], x=lnMh_arr)
            if np.abs(_norm - 1.0) > 1e-5:
                raise RuntimeError('normalization breaks')
        lnMh_mean_arr[i] = np.trapz(p_lnMh_at_lnMs[i, :] * lnMh_arr, x=lnMh_arr)
    # convert results to log-10 base
    lgMs_arr = lnMs_arr / np.log(10.0)
    lgMh_mean_arr = lnMh_mean_arr / np.log(10.0)
    # convert halo mass units from Msun to Msun/h to compare with the values in the mock data
    lgMh_mean_arr = lgMh_mean_arr + np.log10(0.7)
    return(lgMs_arr, lgMh_mean_arr)

def compare_halomass_with_mock_split(p, use_red, mockfile):
    galrec = read_mock(mockfile)
    iscen = galrec['lg_halo_mass'] > 1
    lgmh = galrec['lg_halo_mass'][iscen]
    lgms = galrec['lg_stellar_mass'][iscen]
    gcolor = galrec['g-r'][iscen]
    isred = is_red(lgms, gcolor)
    # check which of them are red vs blue
    if use_red:
        colsel = isred
        xlabel = r"$M_*^{\mathrm{red}}\;[M_\odot/h^2]$"
        color = 'r'
        label = 'Mock Red Data'
        _label = 'Predicted Red'
    else:
        colsel = ~isred
        xlabel = r"$M_*^{\mathrm{blue}}\;[M_\odot/h^2]$"
        color = 'b'
        label = 'Mock Blue Data'
        _label = 'Predicted Blue'
    # prediction!
    lgMs_arr, lgMh_mean_arr = get_halomass_split(p, use_red)
    plt.plot(lgMs_arr, lgMh_mean_arr, color=color, label=_label)
    # select red or blue centrals
    lgmh = lgmh[colsel]
    lgms = lgms[colsel]
    # do measurements in the same way
    lgms_bins = np.linspace(10.0, 11.5, 10)
    lgms_cens = (lgms_bins[1:] + lgms_bins[:-1]) * 0.5
    lgmh_cens = np.zeros_like(lgms_cens)
    lgmh_errs = np.zeros_like(lgms_cens)
    for i in xrange(lgms_cens.size):
        sel = (lgms >= lgms_bins[i]) & (lgms < lgms_bins[i+1])
        nsel = np.sum(sel)
        if nsel > 5:
            # update lgms_cens
            lgms_cens[i] = np.mean(lgms[sel])
            lgmh_cens[i] = np.mean(lgmh[sel])
            lgmh_errs[i] = np.std(lgmh[sel]) / np.sqrt(float(nsel))
    plt.errorbar(lgms_cens, lgmh_cens, yerr=lgmh_errs, color=color, marker="o", ms=5, label=label)
    plt.legend(loc=2)
    plt.xlabel(xlabel)
    plt.ylabel(r"$M_h\;[M_\odot/h]$")
    plt.show()


if __name__ == "__main__":
    mockfile = '/Users/ying/Data/ihodmock/standard/iHODcatalog_bolshoi.h5'
    lgmhqc = 11.94779
    muc = 0.41160
    # good
    # p = [lgmhqc, muc]
    # bad
    # p = [lgmhqc - 0.2, muc + 0.4]
    # use_red = True
    # show_halomass_distribution_split(p, use_red)
    # compare_halomass_with_mock_split(p, use_red, mockfile)
    p = [10.5, 0.7]
    if False:
        show_halomass_distribution_split_ms(p, use_red=True, set_show=False)
        show_halomass_distribution_split_ms(p, use_red=False, set_show=True)
    if False:
        show_stellarmass_distribution_split_ms(p, use_red=True, set_show=False)
        show_stellarmass_distribution_split_ms(p, use_red=False, set_show=True)
    if True:
        lgms_r, lgmh_r = get_halomass_split_ms(p, use_red=True)
        lgms_b, lgmh_b = get_halomass_split_ms(p, use_red=False)
        plt.plot(lgms_r, lgmh_r, 'r-', label="red")
        plt.plot(lgms_b, lgmh_b, 'b--', label="blue")
        plt.legend(loc=2)
        plt.xlabel("stellar mass")
        plt.ylabel("halo mass")
        plt.xlim(10, 12)
        plt.ylim(11, 15)
        plt.show()
